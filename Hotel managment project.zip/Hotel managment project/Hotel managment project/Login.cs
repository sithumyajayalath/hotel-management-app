﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Hotel_managment_project
{
    public partial class Login : Form
    {
        //string path = @"Data Source=DESKTOP-2D23PO9\SQLEXPRESS;Initial Catalog=Hotel;Integrated Security=True;";
       // SqlConnection conn;
        //SqlCommand cmd;

        string name;
        string pw;

        public Login()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
           // conn = new SqlConnection();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void logbtn_Click(object sender, EventArgs e)
        {
            name = uname.Text;
            pw = password.Text;

            try
            {
                /* conn.Open();
                 cmd = new SqlCommand("select * form signin where username = '" + name + "'and password = '" + pw + "'", conn);
                 cmd.ExecuteNonQuery();
                 SqlDataAdapter sd = new SqlDataAdapter();
                 DataTable dt = new DataTable();
                 sd.Fill(dt);*/

                if (name == "admin" && pw == "admin2024")
                {
                    //name = uname.Text;
                    // pw = password.Text;
                    MessageBox.Show("Login successfull", "Successfull");

                    this.Hide();
                    Dashboard dash = new Dashboard();
                    dash.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    uname.Clear();
                    password.Clear();

                    uname.Focus();
                }


            }
            catch (Exception)
            {
                MessageBox.Show("Invalid Username or Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                uname.Clear();
                password.Clear();

                uname.Focus();
            }
            /*finally
            {
                conn.Close();
            }*/
        }

        private void log_close(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
