﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hotel_managment_project
{
    public partial class Dashboard : Form
    {
        Dashboard dashboard;
        Customer customer;
        Booking booking;
        Admin admin;
        Login log;
        Staff staff;

        public Dashboard()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void dash_close(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void custombtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer cus = new Customer();
            cus.ShowDialog();
        }

        private void dash_Click(object sender, EventArgs e)
        {
            if (dashboard == null)
            {
                dashboard = new Dashboard();
                dashboard.FormClosed += dash_close;
                dashboard.MdiParent = this;
                dashboard.Show();
            }
            else
            {
                dashboard.Activate();
            }
        }

        private void dash_close(object sender, FormClosedEventArgs e)
        {
           // throw new NotImplementedException();
           dashboard = null;
        }

        private void staffbtn_Click(object sender, EventArgs e)
        {
            if (staff == null)
            {
                staff = new Staff();
                staff.FormClosed += staff_close;
                staff.MdiParent = this;
                staff.Show();
            }
            else
            {
                staff.Activate();
            }
        }

        private void staff_close(object sender, FormClosedEventArgs e)
        {
            // throw new NotImplementedException();
            staff = null;
        }
    }
}
