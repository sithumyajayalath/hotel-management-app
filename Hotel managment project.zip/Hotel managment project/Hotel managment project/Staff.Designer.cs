﻿namespace Hotel_managment_project
{
    partial class Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Staff));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.outbtn = new System.Windows.Forms.Button();
            this.custombtn = new System.Windows.Forms.Button();
            this.staffbtn = new System.Windows.Forms.Button();
            this.bookbtn = new System.Windows.Forms.Button();
            this.adminbtn = new System.Windows.Forms.Button();
            this.dash = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.sno = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.sname = new System.Windows.Forms.TextBox();
            this.saddress = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.sid = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.sposition = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.smobile = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.smale = new System.Windows.Forms.RadioButton();
            this.sfemale = new System.Windows.Forms.RadioButton();
            this.sdate = new System.Windows.Forms.DateTimePicker();
            this.staffview = new System.Windows.Forms.DataGridView();
            this.searchs = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.delete = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.insert = new System.Windows.Forms.Button();
            this.reset = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.staffview)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.outbtn);
            this.panel1.Controls.Add(this.custombtn);
            this.panel1.Controls.Add(this.staffbtn);
            this.panel1.Controls.Add(this.bookbtn);
            this.panel1.Controls.Add(this.adminbtn);
            this.panel1.Controls.Add(this.dash);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(184, 719);
            this.panel1.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(53, 611);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 22);
            this.label17.TabIndex = 13;
            this.label17.Text = "Admin";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(47, 484);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 22);
            this.label16.TabIndex = 13;
            this.label16.Text = "Booking";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(62, 350);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 22);
            this.label15.TabIndex = 7;
            this.label15.Text = "Staff";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(47, 218);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 22);
            this.label14.TabIndex = 6;
            this.label14.Text = "Customer";
            // 
            // outbtn
            // 
            this.outbtn.BackColor = System.Drawing.Color.Red;
            this.outbtn.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outbtn.Location = new System.Drawing.Point(18, 650);
            this.outbtn.Name = "outbtn";
            this.outbtn.Size = new System.Drawing.Size(138, 47);
            this.outbtn.TabIndex = 5;
            this.outbtn.Text = "LOG OUT";
            this.outbtn.UseVisualStyleBackColor = false;
            // 
            // custombtn
            // 
            this.custombtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.custombtn.Image = ((System.Drawing.Image)(resources.GetObject("custombtn.Image")));
            this.custombtn.Location = new System.Drawing.Point(37, 121);
            this.custombtn.Name = "custombtn";
            this.custombtn.Size = new System.Drawing.Size(103, 96);
            this.custombtn.TabIndex = 4;
            this.custombtn.UseVisualStyleBackColor = false;
            // 
            // staffbtn
            // 
            this.staffbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.staffbtn.Image = ((System.Drawing.Image)(resources.GetObject("staffbtn.Image")));
            this.staffbtn.Location = new System.Drawing.Point(37, 255);
            this.staffbtn.Name = "staffbtn";
            this.staffbtn.Size = new System.Drawing.Size(103, 96);
            this.staffbtn.TabIndex = 3;
            this.staffbtn.UseVisualStyleBackColor = false;
            // 
            // bookbtn
            // 
            this.bookbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.bookbtn.Image = ((System.Drawing.Image)(resources.GetObject("bookbtn.Image")));
            this.bookbtn.Location = new System.Drawing.Point(37, 385);
            this.bookbtn.Name = "bookbtn";
            this.bookbtn.Size = new System.Drawing.Size(103, 96);
            this.bookbtn.TabIndex = 2;
            this.bookbtn.UseVisualStyleBackColor = false;
            // 
            // adminbtn
            // 
            this.adminbtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.adminbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.adminbtn.Image = ((System.Drawing.Image)(resources.GetObject("adminbtn.Image")));
            this.adminbtn.Location = new System.Drawing.Point(37, 517);
            this.adminbtn.Name = "adminbtn";
            this.adminbtn.Size = new System.Drawing.Size(103, 96);
            this.adminbtn.TabIndex = 1;
            this.adminbtn.UseVisualStyleBackColor = false;
            // 
            // dash
            // 
            this.dash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.dash.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dash.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dash.Location = new System.Drawing.Point(13, 49);
            this.dash.Name = "dash";
            this.dash.Size = new System.Drawing.Size(156, 54);
            this.dash.TabIndex = 0;
            this.dash.Text = "Dashboard";
            this.dash.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(222, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 83);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(297, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 28);
            this.label2.TabIndex = 4;
            this.label2.Text = "HOTEL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(298, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(184, 22);
            this.label4.TabIndex = 6;
            this.label4.Text = "spend your time in relax";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1084, 20);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(78, 69);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1021, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 24);
            this.label5.TabIndex = 8;
            this.label5.Text = "name";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel2.Controls.Add(this.sno);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(222, 109);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(940, 61);
            this.panel2.TabIndex = 9;
            // 
            // sno
            // 
            this.sno.AutoSize = true;
            this.sno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(240)))), ((int)(((byte)(254)))));
            this.sno.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sno.Location = new System.Drawing.Point(825, 17);
            this.sno.Name = "sno";
            this.sno.Size = new System.Drawing.Size(56, 31);
            this.sno.TabIndex = 1;
            this.sno.Text = "S01";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(345, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "STAFF REGISTRATION";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(257, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 28);
            this.label6.TabIndex = 10;
            this.label6.Text = "Name";
            // 
            // sname
            // 
            this.sname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sname.Location = new System.Drawing.Point(401, 216);
            this.sname.Name = "sname";
            this.sname.Size = new System.Drawing.Size(293, 32);
            this.sname.TabIndex = 11;
            // 
            // saddress
            // 
            this.saddress.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saddress.Location = new System.Drawing.Point(401, 267);
            this.saddress.Multiline = true;
            this.saddress.Name = "saddress";
            this.saddress.Size = new System.Drawing.Size(293, 84);
            this.saddress.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(257, 267);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 28);
            this.label7.TabIndex = 12;
            this.label7.Text = "Address";
            // 
            // sid
            // 
            this.sid.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sid.Location = new System.Drawing.Point(401, 373);
            this.sid.Name = "sid";
            this.sid.Size = new System.Drawing.Size(293, 32);
            this.sid.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(257, 373);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 28);
            this.label8.TabIndex = 14;
            this.label8.Text = "ID No";
            // 
            // sposition
            // 
            this.sposition.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sposition.Location = new System.Drawing.Point(401, 585);
            this.sposition.Name = "sposition";
            this.sposition.Size = new System.Drawing.Size(290, 32);
            this.sposition.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(256, 585);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 28);
            this.label9.TabIndex = 16;
            this.label9.Text = "Position";
            // 
            // smobile
            // 
            this.smobile.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.smobile.Location = new System.Drawing.Point(401, 535);
            this.smobile.Name = "smobile";
            this.smobile.Size = new System.Drawing.Size(290, 32);
            this.smobile.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(257, 539);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 28);
            this.label10.TabIndex = 18;
            this.label10.Text = "Mobile";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(257, 430);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 28);
            this.label11.TabIndex = 20;
            this.label11.Text = "Gender";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(256, 484);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 28);
            this.label12.TabIndex = 21;
            this.label12.Text = "Date of Birth";
            // 
            // smale
            // 
            this.smale.AutoSize = true;
            this.smale.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.smale.Location = new System.Drawing.Point(401, 426);
            this.smale.Name = "smale";
            this.smale.Size = new System.Drawing.Size(80, 32);
            this.smale.TabIndex = 22;
            this.smale.TabStop = true;
            this.smale.Text = "Male";
            this.smale.UseVisualStyleBackColor = true;
            // 
            // sfemale
            // 
            this.sfemale.AutoSize = true;
            this.sfemale.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sfemale.Location = new System.Drawing.Point(551, 426);
            this.sfemale.Name = "sfemale";
            this.sfemale.Size = new System.Drawing.Size(100, 32);
            this.sfemale.TabIndex = 23;
            this.sfemale.TabStop = true;
            this.sfemale.Text = "Female";
            this.sfemale.UseVisualStyleBackColor = true;
            // 
            // sdate
            // 
            this.sdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sdate.Location = new System.Drawing.Point(401, 485);
            this.sdate.Name = "sdate";
            this.sdate.Size = new System.Drawing.Size(290, 27);
            this.sdate.TabIndex = 24;
            // 
            // staffview
            // 
            this.staffview.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            this.staffview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.staffview.Location = new System.Drawing.Point(744, 254);
            this.staffview.Name = "staffview";
            this.staffview.RowHeadersWidth = 51;
            this.staffview.RowTemplate.Height = 24;
            this.staffview.Size = new System.Drawing.Size(417, 362);
            this.staffview.TabIndex = 25;
            // 
            // searchs
            // 
            this.searchs.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchs.Location = new System.Drawing.Point(936, 208);
            this.searchs.Name = "searchs";
            this.searchs.Size = new System.Drawing.Size(210, 32);
            this.searchs.TabIndex = 26;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(749, 208);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(122, 25);
            this.label13.TabIndex = 27;
            this.label13.Text = "Enter Position";
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.delete.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete.Location = new System.Drawing.Point(701, 645);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(161, 52);
            this.delete.TabIndex = 30;
            this.delete.Text = "DELETE";
            this.delete.UseVisualStyleBackColor = false;
            // 
            // update
            // 
            this.update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(231)))), ((int)(((byte)(113)))));
            this.update.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.Location = new System.Drawing.Point(508, 645);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(161, 52);
            this.update.TabIndex = 29;
            this.update.Text = "UPDATE";
            this.update.UseVisualStyleBackColor = false;
            // 
            // insert
            // 
            this.insert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(241)))), ((int)(((byte)(189)))));
            this.insert.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insert.Location = new System.Drawing.Point(308, 645);
            this.insert.Name = "insert";
            this.insert.Size = new System.Drawing.Size(161, 52);
            this.insert.TabIndex = 28;
            this.insert.Text = "INSERT";
            this.insert.UseVisualStyleBackColor = false;
            // 
            // reset
            // 
            this.reset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(152)))), ((int)(((byte)(228)))));
            this.reset.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reset.Location = new System.Drawing.Point(893, 645);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(161, 52);
            this.reset.TabIndex = 31;
            this.reset.Text = "RESET";
            this.reset.UseVisualStyleBackColor = false;
            // 
            // Staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1186, 719);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.insert);
            this.Controls.Add(this.update);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.searchs);
            this.Controls.Add(this.staffview);
            this.Controls.Add(this.sdate);
            this.Controls.Add(this.sfemale);
            this.Controls.Add(this.smale);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.smobile);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.sposition);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.sid);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.saddress);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.sname);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Name = "Staff";
            this.Text = "Staff";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.staff_close);
            this.Load += new System.EventHandler(this.Staff_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.staffview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button outbtn;
        private System.Windows.Forms.Button custombtn;
        private System.Windows.Forms.Button staffbtn;
        private System.Windows.Forms.Button bookbtn;
        private System.Windows.Forms.Button adminbtn;
        private System.Windows.Forms.Button dash;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label sno;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox sname;
        private System.Windows.Forms.TextBox saddress;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox sid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox sposition;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox smobile;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton smale;
        private System.Windows.Forms.RadioButton sfemale;
        private System.Windows.Forms.DateTimePicker sdate;
        private System.Windows.Forms.DataGridView staffview;
        private System.Windows.Forms.TextBox searchs;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button insert;
        private System.Windows.Forms.Button reset;
    }
}