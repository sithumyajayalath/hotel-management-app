﻿using System;

namespace Hotel_managment_project
{
    partial class Booking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Booking));
            this.staffb = new System.Windows.Forms.Button();
            this.adminb = new System.Windows.Forms.Button();
            this.dashb = new System.Windows.Forms.Button();
            this.bno = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bookb = new System.Windows.Forms.Button();
            this.resetb = new System.Windows.Forms.Button();
            this.deleteb = new System.Windows.Forms.Button();
            this.insertb = new System.Windows.Forms.Button();
            this.updateb = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.searchb = new System.Windows.Forms.TextBox();
            this.bookview = new System.Windows.Forms.DataGridView();
            this.checkin = new System.Windows.Forms.DateTimePicker();
            this.family = new System.Windows.Forms.RadioButton();
            this.single = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.bid = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.outb = new System.Windows.Forms.Button();
            this.customb = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.adult = new System.Windows.Forms.ComboBox();
            this.child = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.night = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.doubleroom = new System.Windows.Forms.RadioButton();
            this.rooms = new System.Windows.Forms.ComboBox();
            this.checkout = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.no = new System.Windows.Forms.RadioButton();
            this.yes = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.bookview)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // staffb
            // 
            this.staffb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.staffb.Image = ((System.Drawing.Image)(resources.GetObject("staffb.Image")));
            this.staffb.Location = new System.Drawing.Point(37, 255);
            this.staffb.Name = "staffb";
            this.staffb.Size = new System.Drawing.Size(103, 96);
            this.staffb.TabIndex = 3;
            this.staffb.UseVisualStyleBackColor = false;
            this.staffb.Click += new System.EventHandler(this.staffb_Click);
            // 
            // adminb
            // 
            this.adminb.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.adminb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.adminb.Image = ((System.Drawing.Image)(resources.GetObject("adminb.Image")));
            this.adminb.Location = new System.Drawing.Point(37, 517);
            this.adminb.Name = "adminb";
            this.adminb.Size = new System.Drawing.Size(103, 96);
            this.adminb.TabIndex = 1;
            this.adminb.UseVisualStyleBackColor = false;
            this.adminb.Click += new System.EventHandler(this.adminb_Click);
            // 
            // dashb
            // 
            this.dashb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.dashb.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashb.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dashb.Location = new System.Drawing.Point(13, 49);
            this.dashb.Name = "dashb";
            this.dashb.Size = new System.Drawing.Size(156, 54);
            this.dashb.TabIndex = 0;
            this.dashb.Text = "Dashboard";
            this.dashb.UseVisualStyleBackColor = false;
            this.dashb.Click += new System.EventHandler(this.dashb_Click);
            // 
            // bno
            // 
            this.bno.AutoSize = true;
            this.bno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(240)))), ((int)(((byte)(254)))));
            this.bno.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bno.Location = new System.Drawing.Point(825, 17);
            this.bno.Name = "bno";
            this.bno.Size = new System.Drawing.Size(58, 31);
            this.bno.TabIndex = 1;
            this.bno.Text = "B01";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(398, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "BOOKING / RESERVATION";
            // 
            // bookb
            // 
            this.bookb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.bookb.Image = ((System.Drawing.Image)(resources.GetObject("bookb.Image")));
            this.bookb.Location = new System.Drawing.Point(37, 385);
            this.bookb.Name = "bookb";
            this.bookb.Size = new System.Drawing.Size(103, 96);
            this.bookb.TabIndex = 2;
            this.bookb.UseVisualStyleBackColor = false;
            this.bookb.Click += new System.EventHandler(this.bookb_Click);
            // 
            // resetb
            // 
            this.resetb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(152)))), ((int)(((byte)(228)))));
            this.resetb.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetb.Location = new System.Drawing.Point(892, 645);
            this.resetb.Name = "resetb";
            this.resetb.Size = new System.Drawing.Size(161, 52);
            this.resetb.TabIndex = 87;
            this.resetb.Text = "RESET";
            this.resetb.UseVisualStyleBackColor = false;
            // 
            // deleteb
            // 
            this.deleteb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.deleteb.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteb.Location = new System.Drawing.Point(700, 645);
            this.deleteb.Name = "deleteb";
            this.deleteb.Size = new System.Drawing.Size(161, 52);
            this.deleteb.TabIndex = 86;
            this.deleteb.Text = "DELETE";
            this.deleteb.UseVisualStyleBackColor = false;
            // 
            // insertb
            // 
            this.insertb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(241)))), ((int)(((byte)(189)))));
            this.insertb.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insertb.Location = new System.Drawing.Point(307, 645);
            this.insertb.Name = "insertb";
            this.insertb.Size = new System.Drawing.Size(161, 52);
            this.insertb.TabIndex = 84;
            this.insertb.Text = "INSERT";
            this.insertb.UseVisualStyleBackColor = false;
            // 
            // updateb
            // 
            this.updateb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(231)))), ((int)(((byte)(113)))));
            this.updateb.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateb.Location = new System.Drawing.Point(507, 645);
            this.updateb.Name = "updateb";
            this.updateb.Size = new System.Drawing.Size(161, 52);
            this.updateb.TabIndex = 85;
            this.updateb.Text = "UPDATE";
            this.updateb.UseVisualStyleBackColor = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(748, 208);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(144, 25);
            this.label13.TabIndex = 83;
            this.label13.Text = "Enter Booking ID";
            // 
            // searchb
            // 
            this.searchb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchb.Location = new System.Drawing.Point(907, 204);
            this.searchb.Name = "searchb";
            this.searchb.Size = new System.Drawing.Size(253, 32);
            this.searchb.TabIndex = 82;
            // 
            // bookview
            // 
            this.bookview.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            this.bookview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bookview.Location = new System.Drawing.Point(743, 254);
            this.bookview.Name = "bookview";
            this.bookview.RowHeadersWidth = 51;
            this.bookview.RowTemplate.Height = 24;
            this.bookview.Size = new System.Drawing.Size(417, 362);
            this.bookview.TabIndex = 81;
            // 
            // checkin
            // 
            this.checkin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkin.Location = new System.Drawing.Point(385, 470);
            this.checkin.Name = "checkin";
            this.checkin.Size = new System.Drawing.Size(290, 27);
            this.checkin.TabIndex = 80;
            // 
            // family
            // 
            this.family.AutoSize = true;
            this.family.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.family.Location = new System.Drawing.Point(608, 367);
            this.family.Name = "family";
            this.family.Size = new System.Drawing.Size(92, 32);
            this.family.TabIndex = 79;
            this.family.TabStop = true;
            this.family.Text = "Family";
            this.family.UseVisualStyleBackColor = true;
            // 
            // single
            // 
            this.single.AutoSize = true;
            this.single.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.single.Location = new System.Drawing.Point(386, 367);
            this.single.Name = "single";
            this.single.Size = new System.Drawing.Size(88, 32);
            this.single.TabIndex = 78;
            this.single.TabStop = true;
            this.single.Text = "Single";
            this.single.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(233, 469);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 28);
            this.label12.TabIndex = 77;
            this.label12.Text = "Check-In";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(233, 371);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 28);
            this.label11.TabIndex = 76;
            this.label11.Text = "BedRoom";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(233, 416);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 28);
            this.label8.TabIndex = 72;
            this.label8.Text = "Rooms";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(233, 260);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(71, 28);
            this.label7.TabIndex = 70;
            this.label7.Text = "Adults";
            // 
            // bid
            // 
            this.bid.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bid.Location = new System.Drawing.Point(386, 202);
            this.bid.Name = "bid";
            this.bid.Size = new System.Drawing.Size(293, 32);
            this.bid.TabIndex = 69;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.outb);
            this.panel1.Controls.Add(this.customb);
            this.panel1.Controls.Add(this.staffb);
            this.panel1.Controls.Add(this.bookb);
            this.panel1.Controls.Add(this.adminb);
            this.panel1.Controls.Add(this.dashb);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(184, 719);
            this.panel1.TabIndex = 61;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(53, 611);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 22);
            this.label17.TabIndex = 13;
            this.label17.Text = "Admin";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(47, 484);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 22);
            this.label16.TabIndex = 13;
            this.label16.Text = "Booking";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(62, 350);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 22);
            this.label15.TabIndex = 7;
            this.label15.Text = "Staff";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(47, 218);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 22);
            this.label14.TabIndex = 6;
            this.label14.Text = "Customer";
            // 
            // outb
            // 
            this.outb.BackColor = System.Drawing.Color.Red;
            this.outb.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outb.Location = new System.Drawing.Point(18, 650);
            this.outb.Name = "outb";
            this.outb.Size = new System.Drawing.Size(138, 47);
            this.outb.TabIndex = 5;
            this.outb.Text = "LOG OUT";
            this.outb.UseVisualStyleBackColor = false;
            this.outb.Click += new System.EventHandler(this.outb_Click);
            // 
            // customb
            // 
            this.customb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.customb.Image = ((System.Drawing.Image)(resources.GetObject("customb.Image")));
            this.customb.Location = new System.Drawing.Point(37, 121);
            this.customb.Name = "customb";
            this.customb.Size = new System.Drawing.Size(103, 96);
            this.customb.TabIndex = 4;
            this.customb.UseVisualStyleBackColor = false;
            this.customb.Click += new System.EventHandler(this.customb_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel2.Controls.Add(this.bno);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(221, 109);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(940, 61);
            this.panel2.TabIndex = 67;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1020, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 24);
            this.label5.TabIndex = 66;
            this.label5.Text = "name";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1083, 20);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(78, 69);
            this.pictureBox2.TabIndex = 65;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(297, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(184, 22);
            this.label4.TabIndex = 64;
            this.label4.Text = "spend your time in relax";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(296, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 28);
            this.label2.TabIndex = 63;
            this.label2.Text = "HOTEL";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(221, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 83);
            this.pictureBox1.TabIndex = 62;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(233, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 28);
            this.label6.TabIndex = 68;
            this.label6.Text = "ID No";
            // 
            // adult
            // 
            this.adult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adult.FormattingEnabled = true;
            this.adult.Location = new System.Drawing.Point(386, 263);
            this.adult.Name = "adult";
            this.adult.Size = new System.Drawing.Size(89, 28);
            this.adult.TabIndex = 88;
            // 
            // child
            // 
            this.child.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.child.FormattingEnabled = true;
            this.child.Location = new System.Drawing.Point(586, 260);
            this.child.Name = "child";
            this.child.Size = new System.Drawing.Size(89, 28);
            this.child.TabIndex = 90;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(509, 260);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 28);
            this.label3.TabIndex = 89;
            this.label3.Text = "Child";
            // 
            // night
            // 
            this.night.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.night.FormattingEnabled = true;
            this.night.Location = new System.Drawing.Point(386, 319);
            this.night.Name = "night";
            this.night.Size = new System.Drawing.Size(89, 28);
            this.night.TabIndex = 92;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(233, 319);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 28);
            this.label9.TabIndex = 91;
            this.label9.Text = "Nights";
            // 
            // doubleroom
            // 
            this.doubleroom.AutoSize = true;
            this.doubleroom.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doubleroom.Location = new System.Drawing.Point(489, 367);
            this.doubleroom.Name = "doubleroom";
            this.doubleroom.Size = new System.Drawing.Size(99, 32);
            this.doubleroom.TabIndex = 93;
            this.doubleroom.TabStop = true;
            this.doubleroom.Text = "Double";
            this.doubleroom.UseVisualStyleBackColor = true;
            // 
            // rooms
            // 
            this.rooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rooms.FormattingEnabled = true;
            this.rooms.Location = new System.Drawing.Point(386, 416);
            this.rooms.Name = "rooms";
            this.rooms.Size = new System.Drawing.Size(142, 28);
            this.rooms.TabIndex = 94;
            // 
            // checkout
            // 
            this.checkout.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkout.Location = new System.Drawing.Point(385, 518);
            this.checkout.Name = "checkout";
            this.checkout.Size = new System.Drawing.Size(290, 27);
            this.checkout.TabIndex = 96;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(233, 517);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 28);
            this.label18.TabIndex = 95;
            this.label18.Text = "Check-Out";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(233, 569);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 28);
            this.label10.TabIndex = 97;
            this.label10.Text = "Food Include";
            // 
            // no
            // 
            this.no.AutoSize = true;
            this.no.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.no.Location = new System.Drawing.Point(479, 567);
            this.no.Name = "no";
            this.no.Size = new System.Drawing.Size(60, 32);
            this.no.TabIndex = 99;
            this.no.TabStop = true;
            this.no.Text = "No";
            this.no.UseVisualStyleBackColor = true;
            // 
            // yes
            // 
            this.yes.AutoSize = true;
            this.yes.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yes.Location = new System.Drawing.Point(388, 569);
            this.yes.Name = "yes";
            this.yes.Size = new System.Drawing.Size(62, 32);
            this.yes.TabIndex = 100;
            this.yes.TabStop = true;
            this.yes.Text = "Yes";
            this.yes.UseVisualStyleBackColor = true;
            // 
            // Booking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1186, 719);
            this.Controls.Add(this.yes);
            this.Controls.Add(this.no);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.checkout);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.rooms);
            this.Controls.Add(this.doubleroom);
            this.Controls.Add(this.night);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.child);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.adult);
            this.Controls.Add(this.resetb);
            this.Controls.Add(this.deleteb);
            this.Controls.Add(this.insertb);
            this.Controls.Add(this.updateb);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.searchb);
            this.Controls.Add(this.bookview);
            this.Controls.Add(this.checkin);
            this.Controls.Add(this.family);
            this.Controls.Add(this.single);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.bid);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Name = "Booking";
            this.Text = "Booking";
            ((System.ComponentModel.ISupportInitialize)(this.bookview)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void customb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void outb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void adminb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void bookb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void dashb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void staffb_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Button staffb;
        private System.Windows.Forms.Button adminb;
        private System.Windows.Forms.Button dashb;
        private System.Windows.Forms.Label bno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bookb;
        private System.Windows.Forms.Button resetb;
        private System.Windows.Forms.Button deleteb;
        private System.Windows.Forms.Button insertb;
        private System.Windows.Forms.Button updateb;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox searchb;
        private System.Windows.Forms.DataGridView bookview;
        private System.Windows.Forms.DateTimePicker checkin;
        private System.Windows.Forms.RadioButton family;
        private System.Windows.Forms.RadioButton single;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox bid;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button outb;
        private System.Windows.Forms.Button customb;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox adult;
        private System.Windows.Forms.ComboBox child;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox night;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton doubleroom;
        private System.Windows.Forms.ComboBox rooms;
        private System.Windows.Forms.DateTimePicker checkout;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton no;
        private System.Windows.Forms.RadioButton yes;
    }
}