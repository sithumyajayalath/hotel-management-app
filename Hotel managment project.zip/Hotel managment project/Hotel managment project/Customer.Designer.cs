﻿using System;

namespace Hotel_managment_project
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customer));
            this.creset = new System.Windows.Forms.Button();
            this.cdelete = new System.Windows.Forms.Button();
            this.cinsert = new System.Windows.Forms.Button();
            this.cupdate = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.searchc = new System.Windows.Forms.TextBox();
            this.customerview = new System.Windows.Forms.DataGridView();
            this.cdate = new System.Windows.Forms.DateTimePicker();
            this.cfemale = new System.Windows.Forms.RadioButton();
            this.cmale = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmobile = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cid = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.caddress = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cname = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.outlog = new System.Windows.Forms.Button();
            this.custom = new System.Windows.Forms.Button();
            this.staf = new System.Windows.Forms.Button();
            this.book = new System.Windows.Forms.Button();
            this.adm = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dashh = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cno = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.customerview)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // creset
            // 
            this.creset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(152)))), ((int)(((byte)(228)))));
            this.creset.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.creset.Location = new System.Drawing.Point(892, 645);
            this.creset.Name = "creset";
            this.creset.Size = new System.Drawing.Size(161, 52);
            this.creset.TabIndex = 60;
            this.creset.Text = "RESET";
            this.creset.UseVisualStyleBackColor = false;
            // 
            // cdelete
            // 
            this.cdelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.cdelete.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cdelete.Location = new System.Drawing.Point(700, 645);
            this.cdelete.Name = "cdelete";
            this.cdelete.Size = new System.Drawing.Size(161, 52);
            this.cdelete.TabIndex = 59;
            this.cdelete.Text = "DELETE";
            this.cdelete.UseVisualStyleBackColor = false;
            // 
            // cinsert
            // 
            this.cinsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(241)))), ((int)(((byte)(189)))));
            this.cinsert.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cinsert.Location = new System.Drawing.Point(307, 645);
            this.cinsert.Name = "cinsert";
            this.cinsert.Size = new System.Drawing.Size(161, 52);
            this.cinsert.TabIndex = 57;
            this.cinsert.Text = "INSERT";
            this.cinsert.UseVisualStyleBackColor = false;
            // 
            // cupdate
            // 
            this.cupdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(231)))), ((int)(((byte)(113)))));
            this.cupdate.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cupdate.Location = new System.Drawing.Point(507, 645);
            this.cupdate.Name = "cupdate";
            this.cupdate.Size = new System.Drawing.Size(161, 52);
            this.cupdate.TabIndex = 58;
            this.cupdate.Text = "UPDATE";
            this.cupdate.UseVisualStyleBackColor = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(748, 208);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 25);
            this.label13.TabIndex = 56;
            this.label13.Text = "Enter ID";
            // 
            // searchc
            // 
            this.searchc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchc.Location = new System.Drawing.Point(892, 208);
            this.searchc.Name = "searchc";
            this.searchc.Size = new System.Drawing.Size(253, 32);
            this.searchc.TabIndex = 55;
            // 
            // customerview
            // 
            this.customerview.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            this.customerview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customerview.Location = new System.Drawing.Point(743, 254);
            this.customerview.Name = "customerview";
            this.customerview.RowHeadersWidth = 51;
            this.customerview.RowTemplate.Height = 24;
            this.customerview.Size = new System.Drawing.Size(417, 362);
            this.customerview.TabIndex = 54;
            // 
            // cdate
            // 
            this.cdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cdate.Location = new System.Drawing.Point(400, 499);
            this.cdate.Name = "cdate";
            this.cdate.Size = new System.Drawing.Size(290, 27);
            this.cdate.TabIndex = 53;
            // 
            // cfemale
            // 
            this.cfemale.AutoSize = true;
            this.cfemale.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cfemale.Location = new System.Drawing.Point(550, 440);
            this.cfemale.Name = "cfemale";
            this.cfemale.Size = new System.Drawing.Size(100, 32);
            this.cfemale.TabIndex = 52;
            this.cfemale.TabStop = true;
            this.cfemale.Text = "Female";
            this.cfemale.UseVisualStyleBackColor = true;
            // 
            // cmale
            // 
            this.cmale.AutoSize = true;
            this.cmale.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmale.Location = new System.Drawing.Point(400, 440);
            this.cmale.Name = "cmale";
            this.cmale.Size = new System.Drawing.Size(80, 32);
            this.cmale.TabIndex = 51;
            this.cmale.TabStop = true;
            this.cmale.Text = "Male";
            this.cmale.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(255, 498);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 28);
            this.label12.TabIndex = 50;
            this.label12.Text = "Date of Birth";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(256, 444);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 28);
            this.label11.TabIndex = 49;
            this.label11.Text = "Gender";
            // 
            // cmobile
            // 
            this.cmobile.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmobile.Location = new System.Drawing.Point(400, 549);
            this.cmobile.Name = "cmobile";
            this.cmobile.Size = new System.Drawing.Size(290, 32);
            this.cmobile.TabIndex = 48;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(256, 553);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 28);
            this.label10.TabIndex = 47;
            this.label10.Text = "Mobile";
            // 
            // cid
            // 
            this.cid.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cid.Location = new System.Drawing.Point(400, 387);
            this.cid.Name = "cid";
            this.cid.Size = new System.Drawing.Size(293, 32);
            this.cid.TabIndex = 44;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(256, 387);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 28);
            this.label8.TabIndex = 43;
            this.label8.Text = "ID No";
            // 
            // caddress
            // 
            this.caddress.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.caddress.Location = new System.Drawing.Point(400, 281);
            this.caddress.Multiline = true;
            this.caddress.Name = "caddress";
            this.caddress.Size = new System.Drawing.Size(293, 84);
            this.caddress.TabIndex = 42;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(256, 281);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 28);
            this.label7.TabIndex = 41;
            this.label7.Text = "Address";
            // 
            // cname
            // 
            this.cname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cname.Location = new System.Drawing.Point(400, 230);
            this.cname.Name = "cname";
            this.cname.Size = new System.Drawing.Size(293, 32);
            this.cname.TabIndex = 40;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel1.Controls.Add(this.outlog);
            this.panel1.Controls.Add(this.custom);
            this.panel1.Controls.Add(this.staf);
            this.panel1.Controls.Add(this.book);
            this.panel1.Controls.Add(this.adm);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.dashh);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(184, 719);
            this.panel1.TabIndex = 32;
            // 
            // outlog
            // 
            this.outlog.BackColor = System.Drawing.Color.Red;
            this.outlog.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outlog.Location = new System.Drawing.Point(24, 647);
            this.outlog.Name = "outlog";
            this.outlog.Size = new System.Drawing.Size(138, 47);
            this.outlog.TabIndex = 18;
            this.outlog.Text = "LOG OUT";
            this.outlog.UseVisualStyleBackColor = false;
            // 
            // custom
            // 
            this.custom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.custom.Image = ((System.Drawing.Image)(resources.GetObject("custom.Image")));
            this.custom.Location = new System.Drawing.Point(41, 113);
            this.custom.Name = "custom";
            this.custom.Size = new System.Drawing.Size(103, 96);
            this.custom.TabIndex = 17;
            this.custom.UseVisualStyleBackColor = false;
            // 
            // staf
            // 
            this.staf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.staf.Image = ((System.Drawing.Image)(resources.GetObject("staf.Image")));
            this.staf.Location = new System.Drawing.Point(41, 247);
            this.staf.Name = "staf";
            this.staf.Size = new System.Drawing.Size(103, 96);
            this.staf.TabIndex = 16;
            this.staf.UseVisualStyleBackColor = false;
            // 
            // book
            // 
            this.book.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.book.Image = ((System.Drawing.Image)(resources.GetObject("book.Image")));
            this.book.Location = new System.Drawing.Point(41, 377);
            this.book.Name = "book";
            this.book.Size = new System.Drawing.Size(103, 96);
            this.book.TabIndex = 15;
            this.book.UseVisualStyleBackColor = false;
            // 
            // adm
            // 
            this.adm.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.adm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.adm.Image = ((System.Drawing.Image)(resources.GetObject("adm.Image")));
            this.adm.Location = new System.Drawing.Point(41, 509);
            this.adm.Name = "adm";
            this.adm.Size = new System.Drawing.Size(103, 96);
            this.adm.TabIndex = 14;
            this.adm.UseVisualStyleBackColor = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(53, 611);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 22);
            this.label17.TabIndex = 13;
            this.label17.Text = "Admin";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(47, 484);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 22);
            this.label16.TabIndex = 13;
            this.label16.Text = "Booking";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(62, 350);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 22);
            this.label15.TabIndex = 7;
            this.label15.Text = "Staff";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(47, 218);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 22);
            this.label14.TabIndex = 6;
            this.label14.Text = "Customer";
            // 
            // dashh
            // 
            this.dashh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.dashh.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashh.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dashh.Location = new System.Drawing.Point(13, 49);
            this.dashh.Name = "dashh";
            this.dashh.Size = new System.Drawing.Size(156, 54);
            this.dashh.TabIndex = 0;
            this.dashh.Text = "Dashboard";
            this.dashh.UseVisualStyleBackColor = false;
            this.dashh.Click += new System.EventHandler(this.dashh_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel2.Controls.Add(this.cno);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(221, 109);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(940, 61);
            this.panel2.TabIndex = 38;
            // 
            // cno
            // 
            this.cno.AutoSize = true;
            this.cno.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(240)))), ((int)(((byte)(254)))));
            this.cno.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cno.Location = new System.Drawing.Point(825, 17);
            this.cno.Name = "cno";
            this.cno.Size = new System.Drawing.Size(57, 31);
            this.cno.TabIndex = 1;
            this.cno.Text = "C01";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(411, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "CUSTOMER REGISTRATION";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1020, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 24);
            this.label5.TabIndex = 37;
            this.label5.Text = "name";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1083, 20);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(78, 69);
            this.pictureBox2.TabIndex = 36;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(297, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(184, 22);
            this.label4.TabIndex = 35;
            this.label4.Text = "spend your time in relax";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(296, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 28);
            this.label2.TabIndex = 34;
            this.label2.Text = "HOTEL";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(221, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 83);
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(256, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 28);
            this.label6.TabIndex = 39;
            this.label6.Text = "Name";
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1186, 719);
            this.Controls.Add(this.creset);
            this.Controls.Add(this.cdelete);
            this.Controls.Add(this.cinsert);
            this.Controls.Add(this.cupdate);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.searchc);
            this.Controls.Add(this.customerview);
            this.Controls.Add(this.cdate);
            this.Controls.Add(this.cfemale);
            this.Controls.Add(this.cmale);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cmobile);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cid);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.caddress);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cname);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Name = "Customer";
            this.Text = "Customer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.custom_close);
            ((System.ComponentModel.ISupportInitialize)(this.customerview)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void dashh_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void outbtton_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Button creset;
        private System.Windows.Forms.Button cdelete;
        private System.Windows.Forms.Button cinsert;
        private System.Windows.Forms.Button cupdate;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox searchc;
        private System.Windows.Forms.DataGridView customerview;
        private System.Windows.Forms.DateTimePicker cdate;
        private System.Windows.Forms.RadioButton cfemale;
        private System.Windows.Forms.RadioButton cmale;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox cmobile;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox cid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox caddress;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox cname;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button dashh;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label cno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private object outbtton;
        private System.Windows.Forms.Button custom;
        private System.Windows.Forms.Button staf;
        private System.Windows.Forms.Button book;
        private System.Windows.Forms.Button adm;
        private System.Windows.Forms.Button outlog;
    }

}