﻿namespace Hotel_managment_project
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.staffbtn = new System.Windows.Forms.Button();
            this.adminbtn = new System.Windows.Forms.Button();
            this.dash = new System.Windows.Forms.Button();
            this.ano = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bookbtn = new System.Windows.Forms.Button();
            this.reset = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.insert = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.adminview = new System.Windows.Forms.DataGridView();
            this.adate = new System.Windows.Forms.DateTimePicker();
            this.afemale = new System.Windows.Forms.RadioButton();
            this.amale = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.amobile = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.pw = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.aname = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.outbtn = new System.Windows.Forms.Button();
            this.custombtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.adminview)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // staffbtn
            // 
            this.staffbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.staffbtn.Image = ((System.Drawing.Image)(resources.GetObject("staffbtn.Image")));
            this.staffbtn.Location = new System.Drawing.Point(37, 255);
            this.staffbtn.Name = "staffbtn";
            this.staffbtn.Size = new System.Drawing.Size(103, 96);
            this.staffbtn.TabIndex = 3;
            this.staffbtn.UseVisualStyleBackColor = false;
            // 
            // adminbtn
            // 
            this.adminbtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.adminbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.adminbtn.Image = ((System.Drawing.Image)(resources.GetObject("adminbtn.Image")));
            this.adminbtn.Location = new System.Drawing.Point(37, 517);
            this.adminbtn.Name = "adminbtn";
            this.adminbtn.Size = new System.Drawing.Size(103, 96);
            this.adminbtn.TabIndex = 1;
            this.adminbtn.UseVisualStyleBackColor = false;
            // 
            // dash
            // 
            this.dash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.dash.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dash.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dash.Location = new System.Drawing.Point(13, 49);
            this.dash.Name = "dash";
            this.dash.Size = new System.Drawing.Size(156, 54);
            this.dash.TabIndex = 0;
            this.dash.Text = "Dashboard";
            this.dash.UseVisualStyleBackColor = false;
            // 
            // ano
            // 
            this.ano.AutoSize = true;
            this.ano.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(240)))), ((int)(((byte)(254)))));
            this.ano.Font = new System.Drawing.Font("Microsoft YaHei", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ano.Location = new System.Drawing.Point(825, 17);
            this.ano.Name = "ano";
            this.ano.Size = new System.Drawing.Size(59, 31);
            this.ano.TabIndex = 1;
            this.ano.Text = "A01";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(356, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADMIN REGISTRATION";
            // 
            // bookbtn
            // 
            this.bookbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.bookbtn.Image = ((System.Drawing.Image)(resources.GetObject("bookbtn.Image")));
            this.bookbtn.Location = new System.Drawing.Point(37, 385);
            this.bookbtn.Name = "bookbtn";
            this.bookbtn.Size = new System.Drawing.Size(103, 96);
            this.bookbtn.TabIndex = 2;
            this.bookbtn.UseVisualStyleBackColor = false;
            // 
            // reset
            // 
            this.reset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(152)))), ((int)(((byte)(228)))));
            this.reset.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reset.Location = new System.Drawing.Point(891, 645);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(161, 52);
            this.reset.TabIndex = 87;
            this.reset.Text = "RESET";
            this.reset.UseVisualStyleBackColor = false;
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(127)))));
            this.delete.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delete.Location = new System.Drawing.Point(699, 645);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(161, 52);
            this.delete.TabIndex = 86;
            this.delete.Text = "DELETE";
            this.delete.UseVisualStyleBackColor = false;
            // 
            // insert
            // 
            this.insert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(241)))), ((int)(((byte)(189)))));
            this.insert.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insert.Location = new System.Drawing.Point(306, 645);
            this.insert.Name = "insert";
            this.insert.Size = new System.Drawing.Size(161, 52);
            this.insert.TabIndex = 84;
            this.insert.Text = "INSERT";
            this.insert.UseVisualStyleBackColor = false;
            // 
            // update
            // 
            this.update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(231)))), ((int)(((byte)(113)))));
            this.update.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.Location = new System.Drawing.Point(506, 645);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(161, 52);
            this.update.TabIndex = 85;
            this.update.Text = "UPDATE";
            this.update.UseVisualStyleBackColor = false;
            // 
            // adminview
            // 
            this.adminview.BackgroundColor = System.Drawing.SystemColors.InactiveBorder;
            this.adminview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adminview.Location = new System.Drawing.Point(727, 198);
            this.adminview.Name = "adminview";
            this.adminview.RowHeadersWidth = 51;
            this.adminview.RowTemplate.Height = 24;
            this.adminview.Size = new System.Drawing.Size(432, 418);
            this.adminview.TabIndex = 81;
            // 
            // adate
            // 
            this.adate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adate.Location = new System.Drawing.Point(399, 445);
            this.adate.Name = "adate";
            this.adate.Size = new System.Drawing.Size(290, 27);
            this.adate.TabIndex = 80;
            // 
            // afemale
            // 
            this.afemale.AutoSize = true;
            this.afemale.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.afemale.Location = new System.Drawing.Point(549, 386);
            this.afemale.Name = "afemale";
            this.afemale.Size = new System.Drawing.Size(100, 32);
            this.afemale.TabIndex = 79;
            this.afemale.TabStop = true;
            this.afemale.Text = "Female";
            this.afemale.UseVisualStyleBackColor = true;
            // 
            // amale
            // 
            this.amale.AutoSize = true;
            this.amale.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amale.Location = new System.Drawing.Point(399, 386);
            this.amale.Name = "amale";
            this.amale.Size = new System.Drawing.Size(80, 32);
            this.amale.TabIndex = 78;
            this.amale.TabStop = true;
            this.amale.Text = "Male";
            this.amale.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(254, 444);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 28);
            this.label12.TabIndex = 77;
            this.label12.Text = "Date of Birth";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(255, 390);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 28);
            this.label11.TabIndex = 76;
            this.label11.Text = "Gender";
            // 
            // amobile
            // 
            this.amobile.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amobile.Location = new System.Drawing.Point(399, 495);
            this.amobile.Name = "amobile";
            this.amobile.Size = new System.Drawing.Size(290, 32);
            this.amobile.TabIndex = 75;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(255, 499);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 28);
            this.label10.TabIndex = 74;
            this.label10.Text = "Mobile";
            // 
            // pw
            // 
            this.pw.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pw.Location = new System.Drawing.Point(399, 333);
            this.pw.Name = "pw";
            this.pw.Size = new System.Drawing.Size(293, 32);
            this.pw.TabIndex = 73;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(255, 333);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 28);
            this.label8.TabIndex = 72;
            this.label8.Text = "Password";
            // 
            // aname
            // 
            this.aname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aname.Location = new System.Drawing.Point(399, 275);
            this.aname.Name = "aname";
            this.aname.Size = new System.Drawing.Size(293, 32);
            this.aname.TabIndex = 69;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.outbtn);
            this.panel1.Controls.Add(this.custombtn);
            this.panel1.Controls.Add(this.staffbtn);
            this.panel1.Controls.Add(this.bookbtn);
            this.panel1.Controls.Add(this.adminbtn);
            this.panel1.Controls.Add(this.dash);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(184, 719);
            this.panel1.TabIndex = 61;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(53, 611);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 22);
            this.label17.TabIndex = 13;
            this.label17.Text = "Admin";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(47, 484);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 22);
            this.label16.TabIndex = 13;
            this.label16.Text = "Booking";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(62, 350);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 22);
            this.label15.TabIndex = 7;
            this.label15.Text = "Staff";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Tai Le", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(47, 218);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 22);
            this.label14.TabIndex = 6;
            this.label14.Text = "Customer";
            // 
            // outbtn
            // 
            this.outbtn.BackColor = System.Drawing.Color.Red;
            this.outbtn.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outbtn.Location = new System.Drawing.Point(18, 650);
            this.outbtn.Name = "outbtn";
            this.outbtn.Size = new System.Drawing.Size(138, 47);
            this.outbtn.TabIndex = 5;
            this.outbtn.Text = "LOG OUT";
            this.outbtn.UseVisualStyleBackColor = false;
            // 
            // custombtn
            // 
            this.custombtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.custombtn.Image = ((System.Drawing.Image)(resources.GetObject("custombtn.Image")));
            this.custombtn.Location = new System.Drawing.Point(37, 121);
            this.custombtn.Name = "custombtn";
            this.custombtn.Size = new System.Drawing.Size(103, 96);
            this.custombtn.TabIndex = 4;
            this.custombtn.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(211)))), ((int)(((byte)(246)))));
            this.panel2.Controls.Add(this.ano);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(220, 109);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(940, 61);
            this.panel2.TabIndex = 67;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1019, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 24);
            this.label5.TabIndex = 66;
            this.label5.Text = "name";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1082, 20);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(78, 69);
            this.pictureBox2.TabIndex = 65;
            this.pictureBox2.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(296, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(184, 22);
            this.label4.TabIndex = 64;
            this.label4.Text = "spend your time in relax";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(295, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 28);
            this.label2.TabIndex = 63;
            this.label2.Text = "HOTEL";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(220, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 83);
            this.pictureBox1.TabIndex = 62;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(255, 275);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 28);
            this.label6.TabIndex = 68;
            this.label6.Text = "Name";
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1186, 719);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.insert);
            this.Controls.Add(this.update);
            this.Controls.Add(this.adminview);
            this.Controls.Add(this.adate);
            this.Controls.Add(this.afemale);
            this.Controls.Add(this.amale);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.amobile);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pw);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.aname);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Name = "Admin";
            this.Text = "Admin";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.admin_close);
            ((System.ComponentModel.ISupportInitialize)(this.adminview)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button staffbtn;
        private System.Windows.Forms.Button adminbtn;
        private System.Windows.Forms.Button dash;
        private System.Windows.Forms.Label ano;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bookbtn;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button insert;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.DataGridView adminview;
        private System.Windows.Forms.DateTimePicker adate;
        private System.Windows.Forms.RadioButton afemale;
        private System.Windows.Forms.RadioButton amale;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox amobile;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox pw;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox aname;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button outbtn;
        private System.Windows.Forms.Button custombtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
    }
}